import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { BookOpen, Users, Scale, Award } from 'lucide-react';

export function ConstitutionFramework() {
  const sections = [
    {
      title: 'The Preamble',
      icon: BookOpen,
      content: 'The Preamble of the Indian Constitution declares India as a SOVEREIGN, SOCIALIST, SECULAR, DEMOCRATIC REPUBLIC and aims to secure justice, liberty, equality, and fraternity for all citizens.',
      highlights: ['Sovereignty', 'Socialism', 'Secularism', 'Democracy', 'Republic']
    },
    {
      title: 'Constitutional Structure',
      icon: Scale,
      content: 'The Constitution consists of 25 Parts, 448 Articles, and 12 Schedules. It establishes the framework of the Indian government, fundamental rights, and directive principles.',
      highlights: ['25 Parts', '448 Articles', '12 Schedules']
    },
    {
      title: 'Three Pillars of Democracy',
      icon: Users,
      content: 'The Constitution establishes three independent branches: Legislature (makes laws), Executive (implements laws), and Judiciary (interprets laws).',
      highlights: ['Legislature', 'Executive', 'Judiciary']
    },
    {
      title: 'Federal System',
      icon: Award,
      content: 'India follows a federal system with division of powers between the Union (Central) Government and State Governments as outlined in the Seventh Schedule.',
      highlights: ['Union List', 'State List', 'Concurrent List']
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">Constitutional Framework</h2>
        <p className="text-gray-600">
          Understanding the basic structure and principles of the Indian Constitution
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {sections.map((section, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <section.icon className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle className="text-lg">{section.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{section.content}</p>
              <div className="flex flex-wrap gap-2">
                {section.highlights.map((highlight, i) => (
                  <Badge key={i} variant="secondary" className="bg-green-100 text-green-800">
                    {highlight}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
