import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { User, BookOpen, Shield, Gavel } from 'lucide-react';

export function UserRoles() {
  const roles = [
    {
      title: 'Citizen',
      icon: User,
      color: 'bg-blue-500',
      description: 'Learn about your rights, duties, and how the Constitution affects your daily life.',
      features: [
        'Access to basic constitutional knowledge',
        'Interactive quizzes and learning modules',
        'Track your learning progress',
        'Participate in community discussions'
      ]
    },
    {
      title: 'Educator',
      icon: BookOpen,
      color: 'bg-green-500',
      description: 'Resources and tools to teach constitutional principles effectively.',
      features: [
        'Advanced learning materials and lesson plans',
        'Create and share educational content',
        'Monitor student progress',
        'Access to pedagogical resources'
      ]
    },
    {
      title: 'Administrator',
      icon: Shield,
      color: 'bg-red-500',
      description: 'Manage platform content, users, and ensure quality education delivery.',
      features: [
        'Content management and moderation',
        'User management and role assignment',
        'Analytics and reporting dashboard',
        'Platform configuration and settings'
      ]
    },
    {
      title: 'Legal Expert',
      icon: Gavel,
      color: 'bg-purple-500',
      description: 'Deep dive into constitutional law, precedents, and legal interpretations.',
      features: [
        'Access to advanced legal materials',
        'Case law and precedent database',
        'Constitutional amendment history',
        'Expert forum and consultation'
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">User Roles & Access</h2>
        <p className="text-gray-600">
          Different roles provide tailored experiences for diverse learning needs
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {roles.map((role, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 ${role.color} rounded-lg flex items-center justify-center`}>
                  <role.icon className="w-6 h-6 text-white" />
                </div>
                <CardTitle>{role.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{role.description}</p>
              <div className="space-y-2">
                {role.features.map((feature, i) => (
                  <div key={i} className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-1.5" />
                    <p className="text-sm text-gray-700">{feature}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
