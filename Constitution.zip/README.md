
  # Constitutional Chat Bot Enhancements

  This is a code bundle for Constitutional Chat Bot Enhancements. The original project is available at https://www.figma.com/design/r11STNp4RhVZoZvM2K6jvo/Constitutional-Chat-Bot-Enhancements.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  