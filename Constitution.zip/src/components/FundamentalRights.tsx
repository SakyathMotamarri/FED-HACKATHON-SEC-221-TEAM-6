import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Shield, UserCheck, Vote, BookText, Briefcase, Building } from 'lucide-react';

export function FundamentalRights() {
  const rights = [
    {
      title: 'Right to Equality',
      articles: 'Articles 14-18',
      icon: Scale,
      description: 'Equality before law, prohibition of discrimination, equality of opportunity in employment, abolition of untouchability, and abolition of titles.',
      keyPoints: ['Equal protection of laws', 'No discrimination', 'Equal employment opportunities']
    },
    {
      title: 'Right to Freedom',
      articles: 'Articles 19-22',
      icon: UserCheck,
      description: 'Freedom of speech and expression, assembly, association, movement, residence, and profession.',
      keyPoints: ['Freedom of speech', 'Right to assemble', 'Freedom of movement']
    },
    {
      title: 'Right against Exploitation',
      articles: 'Articles 23-24',
      icon: Shield,
      description: 'Prohibition of trafficking, forced labor, and employment of children in hazardous work.',
      keyPoints: ['No human trafficking', 'No forced labor', 'No child labor']
    },
    {
      title: 'Right to Freedom of Religion',
      articles: 'Articles 25-28',
      icon: Building,
      description: 'Freedom of conscience, free profession, practice and propagation of religion.',
      keyPoints: ['Freedom of conscience', 'Manage religious affairs', 'No religious instruction in government schools']
    },
    {
      title: 'Cultural and Educational Rights',
      articles: 'Articles 29-30',
      icon: BookText,
      description: 'Protection of interests of minorities to conserve their language, script, and culture.',
      keyPoints: ['Protect minority culture', 'Establish educational institutions', 'Preserve language']
    },
    {
      title: 'Right to Constitutional Remedies',
      articles: 'Article 32',
      icon: Briefcase,
      description: 'Right to move the Supreme Court for enforcement of Fundamental Rights through writs.',
      keyPoints: ['Habeas Corpus', 'Mandamus', 'Prohibition', 'Certiorari', 'Quo Warranto']
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">Fundamental Rights</h2>
        <p className="text-gray-600">
          Six categories of fundamental rights guaranteed to all citizens of India
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {rights.map((right, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <right.icon className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <CardTitle className="text-base">{right.title}</CardTitle>
                  <p className="text-xs text-gray-500">{right.articles}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">{right.description}</p>
              <div className="space-y-1">
                {right.keyPoints.map((point, i) => (
                  <div key={i} className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5" />
                    <p className="text-xs text-gray-700">{point}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Scale({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 3v18M3 12h18M7 7l5-4 5 4M7 17l5 4 5-4" />
    </svg>
  );
}
