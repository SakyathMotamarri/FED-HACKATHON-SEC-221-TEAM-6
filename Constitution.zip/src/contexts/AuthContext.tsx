import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'citizen' | 'educator' | 'admin' | 'legal-expert';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface UserProgress {
  completedSections: string[];
  totalQuizzes: number;
  averageScore: number;
  readingTime: number;
  chaptersCompleted: number;
}

interface AuthContextType {
  user: User | null;
  progress: UserProgress | null;
  signIn: (email: string, password: string, role: UserRole) => Promise<void>;
  signUp: (name: string, email: string, password: string, role: UserRole) => Promise<void>;
  signOut: () => void;
  updateProgress: (section: string, score: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [progress, setProgress] = useState<UserProgress | null>(null);

  const signIn = async (email: string, password: string, role: UserRole) => {
    // Mock authentication - in production, this would call Supabase
    const mockUser: User = {
      id: '1',
      name: email.split('@')[0],
      email,
      role,
    };
    setUser(mockUser);
    setProgress({
      completedSections: [],
      totalQuizzes: 0,
      averageScore: 0,
      readingTime: 0,
      chaptersCompleted: 0,
    });
  };

  const signUp = async (name: string, email: string, password: string, role: UserRole) => {
    // Mock sign up - in production, this would call Supabase
    const mockUser: User = {
      id: '1',
      name,
      email,
      role,
    };
    setUser(mockUser);
    setProgress({
      completedSections: [],
      totalQuizzes: 0,
      averageScore: 0,
      readingTime: 0,
      chaptersCompleted: 0,
    });
  };

  const signOut = () => {
    setUser(null);
    setProgress(null);
  };

  const updateProgress = async (section: string, score: number) => {
    if (!progress) return;

    const updatedSections = progress.completedSections.includes(section)
      ? progress.completedSections
      : [...progress.completedSections, section];

    setProgress({
      ...progress,
      completedSections: updatedSections,
      totalQuizzes: progress.totalQuizzes + 1,
      averageScore: Math.round((progress.averageScore * progress.totalQuizzes + score) / (progress.totalQuizzes + 1)),
    });
  };

  return (
    <AuthContext.Provider value={{ user, progress, signIn, signUp, signOut, updateProgress }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
