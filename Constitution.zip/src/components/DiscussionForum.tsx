import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { MessageCircle, ThumbsUp, Reply, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Discussion {
  id: string;
  title: string;
  content: string;
  author: string;
  role: string;
  category: string;
  likes: number;
  replies: number;
  timestamp: Date;
}

export function DiscussionForum() {
  const { user } = useAuth();
  const [discussions, setDiscussions] = useState<Discussion[]>([
    {
      id: '1',
      title: 'Understanding Article 370 - Historical Context',
      content: 'Can someone explain the historical significance of Article 370 and its recent changes?',
      author: 'Rahul S.',
      role: 'Citizen',
      category: 'Constitutional History',
      likes: 24,
      replies: 8,
      timestamp: new Date('2024-11-01')
    },
    {
      id: '2',
      title: 'Comparison: Indian vs American Federalism',
      content: 'How does the federal structure in India compare with that of the United States?',
      author: 'Dr. Priya M.',
      role: 'Educator',
      category: 'Comparative Study',
      likes: 42,
      replies: 15,
      timestamp: new Date('2024-10-28')
    },
    {
      id: '3',
      title: 'Directive Principles vs Fundamental Rights',
      content: 'Why are Directive Principles non-justiciable while Fundamental Rights are justiciable?',
      author: 'Adv. Kumar',
      role: 'Legal Expert',
      category: 'Constitutional Law',
      likes: 31,
      replies: 12,
      timestamp: new Date('2024-10-25')
    }
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('General Discussion');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const categories = [
    'General Discussion',
    'Fundamental Rights',
    'Constitutional History',
    'Comparative Study',
    'Constitutional Law',
    'Amendments',
    'Judicial Decisions'
  ];

  const handleCreateDiscussion = () => {
    if (!user || !newTitle.trim() || !newContent.trim()) return;

    const discussion: Discussion = {
      id: Date.now().toString(),
      title: newTitle,
      content: newContent,
      author: user.name,
      role: user.role,
      category: newCategory,
      likes: 0,
      replies: 0,
      timestamp: new Date()
    };

    setDiscussions([discussion, ...discussions]);
    setNewTitle('');
    setNewContent('');
    setIsDialogOpen(false);
  };

  const handleLike = (id: string) => {
    setDiscussions(discussions.map(d => 
      d.id === id ? { ...d, likes: d.likes + 1 } : d
    ));
  };

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      'Citizen': 'bg-blue-100 text-blue-800',
      'Educator': 'bg-green-100 text-green-800',
      'Admin': 'bg-red-100 text-red-800',
      'Legal Expert': 'bg-purple-100 text-purple-800',
      'legal-expert': 'bg-purple-100 text-purple-800',
      'educator': 'bg-green-100 text-green-800',
      'admin': 'bg-red-100 text-red-800',
      'citizen': 'bg-blue-100 text-blue-800'
    };
    return colors[role] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="mb-2">Discussion Forum</h2>
          <p className="text-gray-600">
            Engage with the community to discuss constitutional topics
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button disabled={!user}>
              <Plus className="w-4 h-4 mr-2" />
              New Discussion
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Start a New Discussion</DialogTitle>
              <DialogDescription>
                Share your thoughts and questions about constitutional topics with the community.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Input
                  placeholder="Discussion Title"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                />
              </div>
              <div>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              <div>
                <Textarea
                  placeholder="Share your thoughts..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  rows={5}
                />
              </div>
              <Button onClick={handleCreateDiscussion} className="w-full">
                Post Discussion
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {!user && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <p className="text-sm text-blue-800">
              Please sign in to create new discussions and participate in the forum.
            </p>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {discussions.map((discussion) => (
          <Card key={discussion.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <Avatar>
                    <AvatarFallback className="bg-gradient-to-br from-orange-500 to-green-500 text-white">
                      {discussion.author.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-1">{discussion.title}</CardTitle>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <span>{discussion.author}</span>
                      <Badge variant="secondary" className={getRoleColor(discussion.role)}>
                        {discussion.role}
                      </Badge>
                      <span>•</span>
                      <span>{discussion.timestamp.toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
                <Badge variant="outline">{discussion.category}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">{discussion.content}</p>
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleLike(discussion.id)}
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  {discussion.likes}
                </Button>
                <Button variant="ghost" size="sm">
                  <MessageCircle className="w-4 h-4 mr-1" />
                  {discussion.replies} Replies
                </Button>
                <Button variant="ghost" size="sm" disabled={!user}>
                  <Reply className="w-4 h-4 mr-1" />
                  Reply
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
