import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Send, Bot, User, Globe, ChevronDown, ChevronUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  quickReplies?: string[];
}

export function NitiChatBot() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showPrompts, setShowPrompts] = useState(true);
  const [selectedPromptCategory, setSelectedPromptCategory] = useState<string>('all');
  const scrollRef = useRef<HTMLDivElement>(null);

  const promptCategories = {
    basics: [
      'What is a constitution?',
      'Compare fundamental rights in India, USA, and Germany',
      'Explain the Preamble of the Indian Constitution',
      'What are the key features of the US Bill of Rights?'
    ],
    rights: [
      'Compare freedom of speech in different countries',
      'What are socio-economic rights in South Africa?',
      'How does India protect minority rights?',
      'Explain the right to equality in Indian Constitution'
    ],
    government: [
      'Compare presidential and parliamentary systems',
      'How does federalism work in India vs USA?',
      'What is the role of judiciary in constitutional interpretation?',
      'Explain separation of powers'
    ],
    history: [
      'How was the Indian Constitution drafted?',
      'What lessons did India learn from other constitutions?',
      'Explain the historical significance of Magna Carta',
      'How did Japan adopt democracy after WWII?'
    ],
    comparative: [
      'Which country has the most flexible amendment process?',
      'Compare judicial review in India and USA',
      'What makes the UK constitution unique?',
      'How do different countries protect religious freedom?'
    ],
    modern: [
      'How are constitutions adapting to digital age?',
      'What are cyber rights in modern constitutions?',
      'How do constitutions address environmental protection?',
      'Explain data privacy in constitutional context'
    ]
  };

  const knowledgeBase: Record<string, any> = {
    // Greetings
    greetings: {
      keywords: ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'namaste', 'namaskar'],
      responses: [
        "Hello! I'm Niti, your Constitutional Assistant. I'm here to help you learn about constitutions from around the world. What would you like to know?",
        "Hi there! Welcome to Samvidhaan Gyan. I can answer questions about the Indian Constitution and compare it with other countries. How can I assist you today?",
        "Namaste! I'm Niti, and I'm excited to help you explore constitutional knowledge. Ask me anything about constitutions worldwide!"
      ]
    },
    // Conversational
    howAreYou: {
      keywords: ['how are you', 'how are you doing', 'how is it going'],
      response: "I'm doing great, thank you for asking! I'm always excited to discuss constitutional topics. What aspect of the Constitution would you like to explore today?"
    },
    thanks: {
      keywords: ['thank you', 'thanks', 'appreciate'],
      response: "You're very welcome! I'm glad I could help. Feel free to ask more questions anytime!"
    },
    goodbye: {
      keywords: ['bye', 'goodbye', 'see you', 'see you later'],
      response: "Goodbye! Remember, constitutional knowledge empowers citizens. Feel free to return anytime!"
    },
    // Indian Constitution
    fundamentalRights: {
      keywords: ['fundamental rights', 'rights india', 'article 14', 'article 19', 'article 21'],
      response: "The Indian Constitution guarantees 6 Fundamental Rights:\n\n1. Right to Equality (Articles 14-18)\n2. Right to Freedom (Articles 19-22)\n3. Right against Exploitation (Articles 23-24)\n4. Right to Freedom of Religion (Articles 25-28)\n5. Cultural and Educational Rights (Articles 29-30)\n6. Right to Constitutional Remedies (Article 32)\n\nThese rights are justiciable and can be enforced through courts.",
      quickReplies: ['Tell me about Right to Equality', 'Compare with US rights', 'What is Article 32?']
    },
    fundamentalDuties: {
      keywords: ['fundamental duties', 'duties', 'article 51a', 'citizen responsibilities'],
      response: "India has 11 Fundamental Duties under Article 51A, added by the 42nd Amendment in 1976. These include:\n\n• Respecting the Constitution and national symbols\n• Cherishing freedom struggle ideals\n• Protecting sovereignty and unity\n• Defending the country\n• Promoting harmony and brotherhood\n• Preserving composite culture\n• Protecting environment\n• Developing scientific temper\n• Safeguarding public property\n• Striving for excellence\n• Providing education (ages 6-14)",
      quickReplies: ['Compare with other countries', 'Why were these added?', 'Are they enforceable?']
    },
    preamble: {
      keywords: ['preamble', 'we the people', 'sovereign socialist secular'],
      response: "The Preamble declares India as a SOVEREIGN, SOCIALIST, SECULAR, DEMOCRATIC REPUBLIC. It aims to secure:\n\n• JUSTICE - Social, economic, and political\n• LIBERTY - Of thought, expression, belief, faith, and worship\n• EQUALITY - Of status and opportunity\n• FRATERNITY - Promoting dignity and unity\n\nThe words 'Socialist', 'Secular', and 'Integrity' were added by the 42nd Amendment in 1976.",
      quickReplies: ['What does sovereign mean?', 'Compare with US Preamble', 'When was it adopted?']
    },
    // US Constitution
    usConstitution: {
      keywords: ['us constitution', 'american constitution', 'bill of rights', 'amendments usa'],
      response: "The US Constitution, adopted in 1787, is the world's oldest written national constitution. Key features:\n\n• Presidential system with separation of powers\n• Federal structure with strong states' rights\n• Bill of Rights (first 10 amendments) protecting individual freedoms\n• Rigid amendment process (requires 2/3 Congress + 3/4 states)\n• Strong judicial review established by Marbury v. Madison (1803)\n• Currently has 27 amendments\n\nIt emphasizes individual liberty and limited government.",
      quickReplies: ['Compare with Indian Constitution', 'What is judicial review?', 'Explain federalism']
    },
    // UK Constitution
    ukConstitution: {
      keywords: ['uk constitution', 'british constitution', 'unwritten constitution', 'parliamentary sovereignty'],
      response: "The UK has an unwritten (uncodified) constitution based on:\n\n• Parliamentary Acts (Magna Carta 1215, Bill of Rights 1689)\n• Common law and judicial decisions\n• Constitutional conventions\n• Parliamentary sovereignty (Parliament is supreme)\n• No formal judicial review of Acts of Parliament\n• Flexible - can be changed by simple majority\n\nKey documents include Magna Carta, Petition of Right, and Human Rights Act 1998.",
      quickReplies: ['What is Magna Carta?', 'Compare with written constitutions', 'Parliamentary vs Presidential']
    },
    // German Constitution
    germanConstitution: {
      keywords: ['german constitution', 'basic law', 'germany bundesrepublik'],
      response: "Germany's Basic Law (Grundgesetz), adopted in 1949 after WWII:\n\n• Human dignity (Article 1) as foundational principle\n• Federal structure with 16 states (Länder)\n• Strong Constitutional Court (Bundesverfassungsgericht)\n• Eternity clause protecting core values from amendment\n• Social market economy\n• Protection against abuse of power (learned from Nazi era)\n\nIt emphasizes human rights, democracy, and federalism.",
      quickReplies: ['What is human dignity?', 'Compare with Indian federalism', 'What is eternity clause?']
    },
    // Comparative Analysis
    compareRights: {
      keywords: ['compare rights', 'rights comparison', 'different countries rights'],
      response: "Constitutional Rights Comparison:\n\n🇮🇳 INDIA: 6 Fundamental Rights, justiciable, can be suspended during emergency\n\n🇺🇸 USA: Bill of Rights (first 10 amendments), very strong protection, rarely limited\n\n🇩🇪 GERMANY: Human dignity as supreme, rights cannot violate human dignity\n\n🇿🇦 SOUTH AFRICA: Most comprehensive, includes socio-economic rights (housing, healthcare)\n\n🇫🇷 FRANCE: Based on 1789 Declaration, emphasizes equality and laïcité (secularism)",
      quickReplies: ['Which rights are unique to India?', 'What are socio-economic rights?', 'Explain judicial review']
    },
    // Amendment Process
    amendments: {
      keywords: ['amendment', 'constitutional change', 'modify constitution', 'article 368'],
      response: "Constitutional Amendment Comparison:\n\n🇮🇳 INDIA (Article 368):\n• Most flexible: 2/3 majority of Parliament\n• Some need state ratification\n• 105+ amendments since 1950\n\n🇺🇸 USA:\n• Most rigid: 2/3 Congress + 3/4 states\n• Only 27 amendments in 235+ years\n\n🇬🇧 UK:\n• Simple majority can change anything\n• Most flexible\n\n🇩🇪 GERMANY:\n• 2/3 Bundestag + Bundesrat\n• Core values cannot be amended (eternity clause)",
      quickReplies: ['Why is flexibility important?', 'Famous amendments', 'Latest Indian amendments']
    }
  };

  useEffect(() => {
    // Send welcome message
    const roleMessage = user 
      ? `Welcome back, ${user.name}! As a ${user.role}, you have access to comprehensive constitutional knowledge.`
      : 'Welcome! I can help you understand constitutions from around the world.';

    setMessages([{
      id: '1',
      text: `Hello! I'm Niti, your global Constitutional Assistant powered by Samvidhaan Gyan. ${roleMessage}\n\nI have knowledge about constitutions from India, USA, UK, Germany, France, Canada, South Africa, and Japan. Ask me anything!`,
      sender: 'bot',
      timestamp: new Date(),
      quickReplies: ['What are fundamental rights?', 'Compare India and USA constitutions', 'Explain the Preamble']
    }]);
  }, [user]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const findBestResponse = (query: string): { response: string; quickReplies?: string[] } => {
    const lowerQuery = query.toLowerCase().trim();

    // Very short queries
    if (lowerQuery.length < 3) {
      return {
        response: "Could you please provide more details? I'm here to help with constitutional questions!",
        quickReplies: ['Tell me about fundamental rights', 'Compare constitutions', 'Explain federalism']
      };
    }

    // Check each knowledge category
    for (const [key, value] of Object.entries(knowledgeBase)) {
      if ('keywords' in value && Array.isArray(value.keywords)) {
        if (value.keywords.some((keyword: string) => lowerQuery.includes(keyword))) {
          if (Array.isArray(value.responses)) {
            const randomResponse = value.responses[Math.floor(Math.random() * value.responses.length)];
            return { response: randomResponse };
          }
          return {
            response: value.response,
            quickReplies: value.quickReplies
          };
        }
      }
    }

    // Context-aware fallback responses
    if (lowerQuery.includes('when')) {
      return {
        response: "The Indian Constitution was adopted on November 26, 1949, and came into effect on January 26, 1950. For other countries' constitutions, please specify which one you're interested in!",
        quickReplies: ['US Constitution history', 'German Basic Law', 'Constitutional timeline']
      };
    }

    if (lowerQuery.includes('how many')) {
      return {
        response: "The Indian Constitution has:\n• 25 Parts\n• 448 Articles (originally 395)\n• 12 Schedules\n• 105+ Amendments\n\nWhat specific aspect would you like to know more about?",
        quickReplies: ['Fundamental Rights count', 'Fundamental Duties', 'Latest amendments']
      };
    }

    if (lowerQuery.includes('why')) {
      return {
        response: "Constitutional provisions serve various purposes. Could you be more specific about what you'd like to know? For example:\n• Why certain rights were included\n• Why specific amendments were made\n• Why different countries have different structures",
        quickReplies: ['Why fundamental duties?', 'Why amendments?', 'Why federalism?']
      };
    }

    // Default response
    return {
      response: "I can help you with constitutional topics from India and around the world! Try asking about:\n• Fundamental Rights and Duties\n• Constitutional structures and amendments\n• Comparisons between different countries\n• Historical context and landmark judgments\n\nWhat would you like to know?",
      quickReplies: ['Compare rights globally', 'Explain Preamble', 'Constitutional history']
    };
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    setShowPrompts(false);

    // Simulate typing delay
    setTimeout(() => {
      const { response, quickReplies } = findBestResponse(text);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'bot',
        timestamp: new Date(),
        quickReplies
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const handlePromptSelect = (prompt: string) => {
    sendMessage(prompt);
  };

  const allPrompts = Object.values(promptCategories).flat();
  const displayedPrompts = selectedPromptCategory === 'all' 
    ? allPrompts 
    : promptCategories[selectedPromptCategory as keyof typeof promptCategories];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center space-x-2 mb-2">
          <h2>Niti - Global Constitutional Assistant</h2>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <Globe className="w-3 h-3 mr-1" />
            Worldwide Knowledge
          </Badge>
        </div>
        <p className="text-gray-600">
          Ask questions about constitutions from India, USA, UK, Germany, France, Canada, South Africa, and Japan
        </p>
      </div>

      {/* Custom Prompts Section */}
      {showPrompts && messages.length <= 1 && (
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Quick Start Prompts</CardTitle>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowPrompts(false)}
              >
                <ChevronUp className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex flex-wrap gap-2">
              <Button
                variant={selectedPromptCategory === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('all')}
              >
                All
              </Button>
              <Button
                variant={selectedPromptCategory === 'basics' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('basics')}
              >
                📚 Basics
              </Button>
              <Button
                variant={selectedPromptCategory === 'rights' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('rights')}
              >
                ⚖️ Rights
              </Button>
              <Button
                variant={selectedPromptCategory === 'government' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('government')}
              >
                🏛️ Government
              </Button>
              <Button
                variant={selectedPromptCategory === 'history' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('history')}
              >
                📜 History
              </Button>
              <Button
                variant={selectedPromptCategory === 'comparative' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('comparative')}
              >
                🌍 Compare
              </Button>
              <Button
                variant={selectedPromptCategory === 'modern' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPromptCategory('modern')}
              >
                🚀 Modern
              </Button>
            </div>
            <div className="grid gap-2 md:grid-cols-2 max-h-64 overflow-y-auto">
              {displayedPrompts.map((prompt, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="justify-start text-left h-auto py-2 px-3 whitespace-normal"
                  onClick={() => handlePromptSelect(prompt)}
                >
                  {prompt}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {!showPrompts && messages.length > 1 && (
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPrompts(true)}
          >
            <ChevronDown className="w-4 h-4 mr-2" />
            Show Custom Prompts
          </Button>
        </div>
      )}

      <Card className="h-[600px] flex flex-col">
        <CardHeader className="border-b">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-green-500 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg">Chat with Niti</CardTitle>
              <p className="text-xs text-gray-500">Constitutional knowledge at your fingertips</p>
            </div>
          </div>
        </CardHeader>

        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex items-start space-x-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === 'user' ? 'bg-blue-500' : 'bg-gradient-to-br from-orange-500 to-green-500'
                  }`}>
                    {message.sender === 'user' ? (
                      <User className="w-5 h-5 text-white" />
                    ) : (
                      <Bot className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div>
                    <div className={`p-3 rounded-lg ${
                      message.sender === 'user' 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      <p className="whitespace-pre-wrap text-sm">{message.text}</p>
                    </div>
                    {message.quickReplies && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {message.quickReplies.map((reply, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            onClick={() => sendMessage(reply)}
                            className="text-xs"
                          >
                            {reply}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-green-500 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="bg-gray-100 p-3 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        <CardContent className="border-t p-4">
          <div className="flex space-x-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage(input)}
              placeholder="Ask about any constitution..."
              className="flex-1"
            />
            <Button onClick={() => sendMessage(input)} disabled={!input.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            💡 Tip: Try asking comparative questions like "Compare India and USA constitutions"
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
