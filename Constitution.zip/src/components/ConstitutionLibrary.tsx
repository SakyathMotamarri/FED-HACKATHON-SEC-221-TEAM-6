import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Progress } from './ui/progress';
import { BookOpen, Clock, BookmarkPlus, Bookmark, Search, FileText, Award } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Book {
  id: string;
  title: string;
  author: string;
  category: string;
  year: number;
  pages: number;
  description: string;
  chapters: Chapter[];
  coverColor: string;
}

interface Chapter {
  id: string;
  title: string;
  pages: number;
  content: string;
  readingTime: number;
  quiz?: Quiz;
}

interface Quiz {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export function ConstitutionLibrary() {
  const { user } = useAuth();
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [bookmarkedBooks, setBookmarkedBooks] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [readingProgress, setReadingProgress] = useState<Record<string, number>>({});

  const books: Book[] = [
    {
      id: '1',
      title: 'Introduction to the Indian Constitution',
      author: 'Dr. M.P. Singh',
      category: 'Foundation',
      year: 2024,
      pages: 450,
      description: 'A comprehensive guide to understanding the basic principles, structure, and evolution of the Indian Constitution.',
      coverColor: 'from-orange-400 to-orange-600',
      chapters: [
        {
          id: '1-1',
          title: 'The Making of the Constitution',
          pages: 45,
          readingTime: 30,
          content: 'The Indian Constitution was drafted by the Constituent Assembly, which was formed in 1946. Dr. B.R. Ambedkar chaired the Drafting Committee. The Constitution was adopted on November 26, 1949, and came into effect on January 26, 1950.\n\nKey features of the drafting process:\n\n1. The Constituent Assembly had 299 members\n2. It took 2 years, 11 months, and 18 days to complete\n3. The Assembly held 11 sessions spanning 165 days\n4. The Constitution originally had 395 articles and 8 schedules\n\nThe framers studied constitutions from around the world, drawing inspiration from:\n• British parliamentary system\n• US Bill of Rights and federal structure\n• Irish Directive Principles\n• Canadian federation\n• Australian concurrent powers',
          quiz: {
            question: 'When was the Indian Constitution adopted?',
            options: ['January 26, 1950', 'November 26, 1949', 'August 15, 1947', 'January 26, 1949'],
            correct: 1,
            explanation: 'The Constitution was adopted on November 26, 1949, and came into effect on January 26, 1950.'
          }
        },
        {
          id: '1-2',
          title: 'The Preamble - Soul of the Constitution',
          pages: 38,
          readingTime: 25,
          content: 'The Preamble declares the fundamental values and guiding principles of the Constitution.\n\nWE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC...\n\nKey Terms Explained:\n\n• SOVEREIGN: India is independent and not subject to any external authority\n• SOCIALIST: Economic equality and fair distribution of wealth\n• SECULAR: No state religion; equal respect for all religions\n• DEMOCRATIC: Government by the people, for the people\n• REPUBLIC: Head of state is elected, not hereditary\n\nThe Preamble also promises to secure:\n• JUSTICE - Social, economic, and political\n• LIBERTY - Of thought, expression, belief, faith, worship\n• EQUALITY - Of status and opportunity\n• FRATERNITY - Promoting dignity and unity',
          quiz: {
            question: 'Which amendment added "Socialist" and "Secular" to the Preamble?',
            options: ['42nd Amendment', '44th Amendment', '52nd Amendment', '61st Amendment'],
            correct: 0,
            explanation: 'The 42nd Amendment Act of 1976 added "Socialist", "Secular", and "Integrity" to the Preamble.'
          }
        },
        {
          id: '1-3',
          title: 'Fundamental Rights - The Pillars of Liberty',
          pages: 52,
          readingTime: 35,
          content: 'Part III of the Constitution (Articles 12-35) deals with Fundamental Rights. These are justiciable rights that can be enforced through courts.\n\nThe Six Categories:\n\n1. RIGHT TO EQUALITY (Articles 14-18)\n• Equality before law\n• Prohibition of discrimination\n• Equality of opportunity in public employment\n• Abolition of untouchability\n• Abolition of titles\n\n2. RIGHT TO FREEDOM (Articles 19-22)\n• Freedom of speech and expression\n• Freedom to assemble peacefully\n• Freedom to form associations\n• Freedom of movement\n• Freedom to reside and settle\n• Freedom to practice any profession\n\n3. RIGHT AGAINST EXPLOITATION (Articles 23-24)\n• Prohibition of human trafficking\n• Prohibition of forced labor\n• Prohibition of child labor in hazardous work\n\n4. RIGHT TO FREEDOM OF RELIGION (Articles 25-28)\n• Freedom of conscience\n• Freedom to profess, practice, and propagate religion\n• Freedom to manage religious affairs\n\n5. CULTURAL AND EDUCATIONAL RIGHTS (Articles 29-30)\n• Protection of minorities\n• Right to conserve culture, language, script\n• Right to establish educational institutions\n\n6. RIGHT TO CONSTITUTIONAL REMEDIES (Article 32)\n• Right to move Supreme Court for enforcement of rights\n• Five types of writs: Habeas Corpus, Mandamus, Prohibition, Certiorari, Quo Warranto',
          quiz: {
            question: 'Which article is called the "Heart and Soul" of the Constitution?',
            options: ['Article 14', 'Article 19', 'Article 21', 'Article 32'],
            correct: 3,
            explanation: 'Article 32 (Right to Constitutional Remedies) is called the "Heart and Soul" of the Constitution by Dr. Ambedkar, as it provides the means to enforce other fundamental rights.'
          }
        }
      ]
    },
    {
      id: '2',
      title: 'Fundamental Rights: A Comprehensive Study',
      author: 'Justice V.R. Krishna Iyer',
      category: 'Rights & Freedoms',
      year: 2024,
      pages: 380,
      description: 'An in-depth analysis of fundamental rights, their evolution, and landmark judgments.',
      coverColor: 'from-blue-400 to-blue-600',
      chapters: [
        {
          id: '2-1',
          title: 'Evolution of Rights in India',
          pages: 42,
          readingTime: 28,
          content: 'The concept of fundamental rights in India has evolved significantly since independence.\n\nHistorical Development:\n\n1. Pre-Independence Period:\n• Government of India Act, 1935 had limited protections\n• Freedom struggle emphasized civil liberties\n• Provincial constitutions had some rights provisions\n\n2. Constituent Assembly Debates:\n• Extensive discussions on scope and limitations\n• Balancing individual liberty with social welfare\n• Drawing from international human rights movements\n\n3. Post-Independence Amendments:\n• 1st Amendment (1951): Restrictions on free speech\n• 24th Amendment (1971): Parliament\'s power to amend rights\n• 25th Amendment (1971): Right to property modified\n• 44th Amendment (1978): Right to property removed from Part III\n\nKey Landmark Cases:\n\n• Kesavananda Bharati (1973): Basic Structure Doctrine\n• Maneka Gandhi (1978): Expanded Article 21\n• Vishaka (1997): Sexual harassment guidelines\n• NALSA (2014): Transgender rights\n• Puttaswamy (2017): Right to privacy',
          quiz: {
            question: 'Which case established the Basic Structure Doctrine?',
            options: ['Golaknath', 'Kesavananda Bharati', 'Minerva Mills', 'Maneka Gandhi'],
            correct: 1,
            explanation: 'Kesavananda Bharati v. State of Kerala (1973) established the Basic Structure Doctrine, which limits Parliament\'s power to amend the Constitution.'
          }
        }
      ]
    },
    {
      id: '3',
      title: 'Directive Principles of State Policy',
      author: 'Dr. Durga Das Basu',
      category: 'Constitutional Principles',
      year: 2023,
      pages: 295,
      description: 'Understanding the non-justiciable principles that guide state policy and legislation.',
      coverColor: 'from-green-400 to-green-600',
      chapters: [
        {
          id: '3-1',
          title: 'Nature and Significance of DPSPs',
          pages: 38,
          readingTime: 25,
          content: 'Directive Principles of State Policy (DPSPs) are contained in Part IV (Articles 36-51) of the Constitution.\n\nKey Characteristics:\n\n• Non-Justiciable: Cannot be enforced through courts\n• Fundamental in governance: State should apply them in making laws\n• Positive obligations: Require state action\n• Supplement Fundamental Rights: Work together for welfare\n\nCategories of DPSPs:\n\n1. SOCIALISTIC PRINCIPLES:\n• Adequate means of livelihood (Article 39)\n• Equal pay for equal work (Article 39)\n• Protection of children and youth (Article 39)\n• Right to work and education (Article 41)\n• Living wage and working conditions (Article 43)\n\n2. GANDHIAN PRINCIPLES:\n• Village panchayats (Article 40)\n• Right to work (Article 41)\n• Cottage industries (Article 43)\n• Prohibition of intoxicants (Article 47)\n• Protection of monuments (Article 49)\n\n3. LIBERAL-INTELLECTUAL PRINCIPLES:\n• Uniform Civil Code (Article 44)\n• Free legal aid (Article 39A)\n• Participation in management (Article 43A)\n• Environment protection (Article 48A)\n• International peace (Article 51)',
          quiz: {
            question: 'Which article deals with Uniform Civil Code?',
            options: ['Article 40', 'Article 44', 'Article 48', 'Article 51'],
            correct: 1,
            explanation: 'Article 44 directs the State to secure a Uniform Civil Code for all citizens throughout India.'
          }
        }
      ]
    },
    {
      id: '4',
      title: 'Constitutional Amendments: 2024 Edition',
      author: 'Constitutional Law Institute',
      category: 'Latest Updates',
      year: 2024,
      pages: 325,
      description: 'Latest constitutional amendments, recent judgments, and emerging legal trends in 2024.',
      coverColor: 'from-purple-400 to-purple-600',
      chapters: [
        {
          id: '4-1',
          title: 'Recent Constitutional Developments',
          pages: 45,
          readingTime: 30,
          content: 'Constitutional law continues to evolve through amendments and judicial interpretations.\n\nRecent Key Developments (2023-2024):\n\n1. DIGITAL RIGHTS AND PRIVACY:\n• Data Protection framework discussions\n• Digital constitutional rights debates\n• Aadhaar and privacy balance\n• Cryptocurrency regulation challenges\n\n2. FEDERALISM ISSUES:\n• Centre-State relations during pandemic\n• GST implementation challenges\n• Cooperative federalism evolution\n• State autonomy debates\n\n3. ENVIRONMENTAL CONSTITUTIONALISM:\n• Climate change and constitutional obligations\n• Right to clean environment expansion\n• Intergenerational equity principles\n• Sustainable development mandates\n\n4. SOCIAL JUSTICE ADVANCEMENTS:\n• Reservation policy refinements\n• Gender justice initiatives\n• LGBTQ+ rights recognition\n• Disability rights implementation\n\n5. ELECTORAL REFORMS:\n• Campaign finance transparency\n• Electronic voting debates\n• Criminalisation of politics\n• Inner-party democracy\n\nLandmark 2024 Developments:\n• Same-sex marriage discussions\n• Right to disconnect from work\n• AI and constitutional rights\n• Climate litigation strategies',
          quiz: {
            question: 'Which fundamental right was recognized in the Puttaswamy case?',
            options: ['Right to Education', 'Right to Privacy', 'Right to Information', 'Right to Food'],
            correct: 1,
            explanation: 'Justice K.S. Puttaswamy v. Union of India (2017) recognized the Right to Privacy as a fundamental right under Article 21.'
          }
        }
      ]
    },
    {
      id: '5',
      title: 'Comparative Constitutional Law',
      author: 'Prof. Upendra Baxi',
      category: 'Comparative Study',
      year: 2024,
      pages: 425,
      description: 'Compare constitutional frameworks, rights, and governance structures across major democracies.',
      coverColor: 'from-red-400 to-red-600',
      chapters: [
        {
          id: '5-1',
          title: 'Federalism: India, USA, and Germany',
          pages: 50,
          readingTime: 35,
          content: 'Federal systems distribute power between central and regional governments.\n\nINDIA (Quasi-Federal):\n• Strong Centre with emergency powers\n• Three Lists: Union, State, Concurrent\n• Single Constitution for entire country\n• Appointment of Governors by Centre\n• Integrated judiciary\n• Single citizenship\n\nUSA (Dual Federalism):\n• Strong states\' rights tradition\n• Federal and state constitutions\n• Clear separation of powers\n• Elected state governors\n• Dual judiciary (federal and state)\n• Dual citizenship possible\n\nGERMANY (Cooperative Federalism):\n• 16 federal states (Länder)\n• Bundesrat represents states\n• Cooperative policy-making\n• Strong Constitutional Court\n• Shared taxation system\n• Eternity clause protects federal structure\n\nKEY DIFFERENCES:\n\n1. DISTRIBUTION OF POWERS:\n• India: Residuary powers with Centre\n• USA: Residuary powers with States\n• Germany: Shared legislation model\n\n2. EMERGENCY PROVISIONS:\n• India: Extensive emergency powers\n• USA: Limited federal emergency power\n• Germany: Constitutional emergency provisions\n\n3. FINANCIAL RELATIONS:\n• India: Finance Commission allocations\n• USA: Federal grants and state taxation\n• Germany: Fiscal equalization system',
          quiz: {
            question: 'Where do residuary powers lie in the Indian federal system?',
            options: ['With States', 'With Centre', 'Shared between Centre and States', 'With Supreme Court'],
            correct: 1,
            explanation: 'In India, residuary powers (matters not mentioned in any list) rest with the Union (Central) Government under Article 248.'
          }
        }
      ]
    }
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    book.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleBookmark = (bookId: string) => {
    setBookmarkedBooks(prev =>
      prev.includes(bookId)
        ? prev.filter(id => id !== bookId)
        : [...prev, bookId]
    );
  };

  const startReading = (book: Book, chapter: Chapter) => {
    setSelectedBook(book);
    setSelectedChapter(chapter);
  };

  const markChapterComplete = (bookId: string, chapterId: string) => {
    const key = `${bookId}-${chapterId}`;
    setReadingProgress(prev => ({ ...prev, [key]: 100 }));
  };

  const getBookProgress = (bookId: string) => {
    const book = books.find(b => b.id === bookId);
    if (!book) return 0;
    
    const completedChapters = book.chapters.filter(ch => 
      readingProgress[`${bookId}-${ch.id}`] === 100
    ).length;
    
    return Math.round((completedChapters / book.chapters.length) * 100);
  };

  const totalBooksStarted = books.filter(book => getBookProgress(book.id) > 0).length;
  const totalChaptersCompleted = Object.values(readingProgress).filter(p => p === 100).length;
  const totalReadingTime = Object.keys(readingProgress)
    .filter(key => readingProgress[key] === 100)
    .reduce((total, key) => {
      const [bookId, chapterId] = key.split('-');
      const book = books.find(b => b.id === bookId);
      const chapter = book?.chapters.find(ch => ch.id.includes(chapterId));
      return total + (chapter?.readingTime || 0);
    }, 0);

  if (selectedChapter && selectedBook) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="mb-1">{selectedChapter.title}</h2>
            <p className="text-sm text-gray-600">{selectedBook.title} • {selectedChapter.readingTime} min read</p>
          </div>
          <Button onClick={() => { setSelectedChapter(null); setSelectedBook(null); }}>
            Back to Library
          </Button>
        </div>

        <Card>
          <CardContent className="p-8">
            <div className="prose max-w-none">
              <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                {selectedChapter.content}
              </div>
            </div>

            {selectedChapter.quiz && (
              <div className="mt-8 p-6 bg-orange-50 border-2 border-orange-200 rounded-lg">
                <div className="flex items-center space-x-2 mb-4">
                  <Award className="w-5 h-5 text-orange-600" />
                  <h3 className="text-lg">Chapter Quiz</h3>
                </div>
                <p className="mb-4">{selectedChapter.quiz.question}</p>
                <div className="space-y-2">
                  {selectedChapter.quiz.options.map((option, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => {
                        if (index === selectedChapter.quiz!.correct) {
                          alert(`Correct! ${selectedChapter.quiz!.explanation}`);
                          markChapterComplete(selectedBook.id, selectedChapter.id);
                        } else {
                          alert(`Incorrect. ${selectedChapter.quiz!.explanation}`);
                        }
                      }}
                    >
                      {option}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-8 flex justify-between">
              <Button
                variant="outline"
                onClick={() => markChapterComplete(selectedBook.id, selectedChapter.id)}
              >
                Mark as Complete
              </Button>
              <Button onClick={() => setSelectedChapter(null)}>
                Back to Chapters
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (selectedBook) {
    const progress = getBookProgress(selectedBook.id);
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="mb-1">{selectedBook.title}</h2>
            <p className="text-gray-600">by {selectedBook.author}</p>
          </div>
          <Button onClick={() => setSelectedBook(null)}>Back to Library</Button>
        </div>

        <Card className={`bg-gradient-to-br ${selectedBook.coverColor} text-white`}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="mb-2">{selectedBook.title}</h3>
                <p className="text-white/90 mb-4">{selectedBook.description}</p>
                <div className="flex items-center space-x-4 text-sm">
                  <span>{selectedBook.pages} pages</span>
                  <span>•</span>
                  <span>{selectedBook.chapters.length} chapters</span>
                  <span>•</span>
                  <span>{selectedBook.year}</span>
                </div>
              </div>
              <Button
                variant="secondary"
                size="icon"
                onClick={() => toggleBookmark(selectedBook.id)}
              >
                {bookmarkedBooks.includes(selectedBook.id) ? (
                  <Bookmark className="w-4 h-4 fill-current" />
                ) : (
                  <BookmarkPlus className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Reading Progress</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="bg-white/20" />
            </div>
          </CardContent>
        </Card>

        <div>
          <h3 className="mb-4">Chapters</h3>
          <div className="space-y-3">
            {selectedBook.chapters.map((chapter, index) => {
              const isComplete = readingProgress[`${selectedBook.id}-${chapter.id}`] === 100;
              
              return (
                <Card key={chapter.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge variant="outline">Chapter {index + 1}</Badge>
                          {isComplete && (
                            <Badge className="bg-green-100 text-green-800">Completed</Badge>
                          )}
                        </div>
                        <h4 className="mb-2">{chapter.title}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span className="flex items-center">
                            <FileText className="w-4 h-4 mr-1" />
                            {chapter.pages} pages
                          </span>
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {chapter.readingTime} min
                          </span>
                        </div>
                      </div>
                      <Button onClick={() => startReading(selectedBook, chapter)}>
                        {isComplete ? 'Read Again' : 'Start Reading'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">Constitution Library</h2>
        <p className="text-gray-600">
          Comprehensive textbooks and latest law books on constitutional topics
        </p>
      </div>

      {user && (
        <Card className="bg-gradient-to-br from-orange-50 to-green-50 border-orange-200">
          <CardContent className="p-6">
            <h3 className="mb-4">Your Reading Progress</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl mb-1">{totalBooksStarted}</div>
                <div className="text-sm text-gray-600">Books Started</div>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-1">{totalChaptersCompleted}</div>
                <div className="text-sm text-gray-600">Chapters Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl mb-1">{totalReadingTime}</div>
                <div className="text-sm text-gray-600">Minutes Read</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search books by title, author, or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredBooks.map((book) => {
          const progress = getBookProgress(book.id);
          const isBookmarked = bookmarkedBooks.includes(book.id);
          
          return (
            <Card key={book.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <div className={`h-32 bg-gradient-to-br ${book.coverColor} rounded-t-lg relative`}>
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleBookmark(book.id);
                  }}
                >
                  {isBookmarked ? (
                    <Bookmark className="w-4 h-4 fill-current" />
                  ) : (
                    <BookmarkPlus className="w-4 h-4" />
                  )}
                </Button>
                <div className="absolute bottom-4 left-4 right-4">
                  <Badge variant="secondary">{book.category}</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-lg">{book.title}</CardTitle>
                <p className="text-sm text-gray-600">by {book.author}</p>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-700 mb-4 line-clamp-2">{book.description}</p>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <span>{book.pages} pages</span>
                  <span>{book.chapters.length} chapters</span>
                  <span>{book.year}</span>
                </div>
                {progress > 0 && (
                  <div className="mb-3">
                    <div className="flex justify-between text-xs text-gray-600 mb-1">
                      <span>Progress</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-1.5" />
                  </div>
                )}
                <Button 
                  onClick={() => setSelectedBook(book)} 
                  className="w-full"
                  variant={progress > 0 ? 'default' : 'outline'}
                >
                  <BookOpen className="w-4 h-4 mr-2" />
                  {progress > 0 ? 'Continue Reading' : 'Start Reading'}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
