import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, Award } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function InteractiveQuiz() {
  const { user, updateProgress } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const questions = [
    {
      question: 'How many Fundamental Rights are guaranteed by the Indian Constitution?',
      options: ['5', '6', '7', '8'],
      correct: 1,
      explanation: 'The Indian Constitution guarantees 6 Fundamental Rights under Articles 14-32.'
    },
    {
      question: 'Which article of the Constitution abolishes untouchability?',
      options: ['Article 14', 'Article 15', 'Article 17', 'Article 19'],
      correct: 2,
      explanation: 'Article 17 abolishes untouchability and forbids its practice in any form.'
    },
    {
      question: 'In which year was the Constitution of India adopted?',
      options: ['1947', '1949', '1950', '1952'],
      correct: 1,
      explanation: 'The Constitution was adopted on November 26, 1949, and came into effect on January 26, 1950.'
    },
    {
      question: 'How many Fundamental Duties are mentioned in the Constitution?',
      options: ['10', '11', '12', '13'],
      correct: 1,
      explanation: 'There are 11 Fundamental Duties listed in Article 51A of the Constitution.'
    },
    {
      question: 'Which part of the Constitution deals with Fundamental Rights?',
      options: ['Part II', 'Part III', 'Part IV', 'Part V'],
      correct: 1,
      explanation: 'Part III (Articles 12-35) of the Constitution deals with Fundamental Rights.'
    }
  ];

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index);
    setShowResult(true);
    
    if (index === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const handleNext = async () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizCompleted(true);
      const finalScore = Math.round((score / questions.length) * 100);
      if (user) {
        await updateProgress('constitutional-quiz', finalScore);
      }
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setQuizCompleted(false);
  };

  if (quizCompleted) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="space-y-6">
        <Card className="bg-gradient-to-br from-orange-50 to-green-50">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-10 h-10 text-white" />
            </div>
            <h2 className="mb-2">Quiz Completed!</h2>
            <p className="text-gray-600 mb-6">
              You scored {score} out of {questions.length} questions
            </p>
            <div className="mb-6">
              <div className="text-4xl mb-2">{percentage}%</div>
              <Progress value={percentage} className="h-3" />
            </div>
            <Button onClick={resetQuiz} size="lg">
              Take Quiz Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">Constitutional Knowledge Quiz</h2>
        <p className="text-gray-600">Test your understanding of the Indian Constitution</p>
      </div>

      <div className="mb-4">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>Score: {score}/{questions.length}</span>
        </div>
        <Progress value={progress} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{question.question}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {question.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrect = index === question.correct;
              const showCorrect = showResult && isCorrect;
              const showIncorrect = showResult && isSelected && !isCorrect;

              return (
                <button
                  key={index}
                  onClick={() => !showResult && handleAnswer(index)}
                  disabled={showResult}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                    showCorrect
                      ? 'border-green-500 bg-green-50'
                      : showIncorrect
                      ? 'border-red-500 bg-red-50'
                      : isSelected
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  } ${showResult ? 'cursor-default' : 'cursor-pointer'}`}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    {showCorrect && <CheckCircle className="w-5 h-5 text-green-600" />}
                    {showIncorrect && <XCircle className="w-5 h-5 text-red-600" />}
                  </div>
                </button>
              );
            })}
          </div>

          {showResult && (
            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-900">
                <strong>Explanation:</strong> {question.explanation}
              </p>
            </div>
          )}

          {showResult && (
            <div className="mt-4">
              <Button onClick={handleNext} className="w-full">
                {currentQuestion < questions.length - 1 ? 'Next Question' : 'Complete Quiz'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
