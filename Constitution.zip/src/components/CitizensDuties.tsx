import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle } from 'lucide-react';

export function CitizensDuties() {
  const duties = [
    'To abide by the Constitution and respect its ideals and institutions, the National Flag and the National Anthem',
    'To cherish and follow the noble ideals which inspired our national struggle for freedom',
    'To uphold and protect the sovereignty, unity and integrity of India',
    'To defend the country and render national service when called upon to do so',
    'To promote harmony and the spirit of common brotherhood amongst all the people of India',
    'To value and preserve the rich heritage of our composite culture',
    'To protect and improve the natural environment including forests, lakes, rivers, wildlife',
    'To develop the scientific temper, humanism and the spirit of inquiry and reform',
    'To safeguard public property and to abjure violence',
    'To strive towards excellence in all spheres of individual and collective activity',
    'To provide opportunities for education to children between the age of 6 and 14 years (added by 86th Amendment)'
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-2">Fundamental Duties</h2>
        <p className="text-gray-600">
          Article 51A outlines 11 fundamental duties for every citizen of India
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>11 Fundamental Duties (Article 51A)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {duties.map((duty, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-gray-700">
                    <span className="text-green-600">{index + 1}.</span> {duty}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-orange-50 to-green-50 border-orange-200">
        <CardContent className="p-6">
          <h3 className="mb-3">Historical Context</h3>
          <p className="text-gray-700 mb-2">
            Fundamental Duties were added to the Constitution by the 42nd Amendment Act in 1976, based on the recommendations of the Swaran Singh Committee.
          </p>
          <p className="text-gray-700">
            The 86th Constitutional Amendment Act, 2002, added the 11th Fundamental Duty which requires parents or guardians to provide opportunities for education to their children.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
